package mycomment.exception;

public class MyCommentException extends Exception {
	public MyCommentException(String message){
		super(message);
	}
}
