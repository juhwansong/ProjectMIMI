package bestboard.exception;

public class BestBoardException extends Exception {
	public BestBoardException(String message){
		super(message);
	}
}
