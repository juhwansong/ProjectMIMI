package adminboard.exception;

public class AdminBoardException extends Exception {
	public AdminBoardException(String message){
		super(message);
	}
}
