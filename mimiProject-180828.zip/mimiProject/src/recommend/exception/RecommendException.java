package recommend.exception;

public class RecommendException extends Exception {
	public RecommendException(String message){
		super(message);
	}
}
