package myboard.exception;

public class MyBoardException extends Exception {
	public MyBoardException(String message){
		super(message);
	}
}
