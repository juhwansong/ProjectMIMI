package notice.exception;

public class NoticeException extends Exception {
	public NoticeException(String message){
		super(message);
	}
}
