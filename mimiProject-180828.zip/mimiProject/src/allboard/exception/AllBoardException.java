package allboard.exception;

public class AllBoardException extends Exception {
	public AllBoardException(String message){
		super(message);
	}
}
