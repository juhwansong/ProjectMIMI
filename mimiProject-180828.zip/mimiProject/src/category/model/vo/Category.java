package category.model.vo;

import java.io.Serializable;

public class Category implements Serializable {
	private String categoryNo;  //카테고리번호
	private String categoryFood;//카테고리이름(음식)

}
