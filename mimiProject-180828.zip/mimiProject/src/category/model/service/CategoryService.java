package category.model.service;

import java.util.ArrayList;

import category.exception.CategoryException;
import category.model.vo.Category;

public class CategoryService {
	public CategoryService(){}
	
	public ArrayList<Category> selectCategoryList() throws CategoryException{ //전체 카테고리 목록 조회
		return null;
	}
	
}
