package bookmark.exception;

public class BookmarkException extends Exception {
	public BookmarkException(String message){
		super(message);
	}
}
