package userboard.exception;

public class UserBoardException extends Exception {
	public UserBoardException(String message){
		super(message);
	}
}
