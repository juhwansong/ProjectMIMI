package support.exception;

public class SupportException extends Exception {
	public SupportException(String message){
		super(message);
	}
}
