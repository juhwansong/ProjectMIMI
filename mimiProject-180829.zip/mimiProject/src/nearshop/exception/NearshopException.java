package nearshop.exception;

public class NearshopException extends Exception {
	public NearshopException(String message){
		super(message);
	}
}
