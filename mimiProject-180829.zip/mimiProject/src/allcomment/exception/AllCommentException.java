package allcomment.exception;

public class AllCommentException extends Exception {
	public AllCommentException(String message){
		super(message);
	}
}
