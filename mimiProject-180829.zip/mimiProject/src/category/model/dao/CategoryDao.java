package category.model.dao;

public class CategoryDao {

}
